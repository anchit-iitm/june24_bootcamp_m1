from flask_mail import Mail

mail = Mail()